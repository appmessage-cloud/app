package com.muroming.postcardeditor.listeners

interface OnBackPressedListener {
    fun onBackPressed(): Boolean
}