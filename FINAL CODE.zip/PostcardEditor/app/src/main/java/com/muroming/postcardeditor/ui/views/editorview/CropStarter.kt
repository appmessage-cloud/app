package com.muroming.postcardeditor.ui.views.editorview

interface CropStarter {
    fun startCrop()
}