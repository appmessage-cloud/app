package com.muroming.postcardeditor.listeners

interface OnKeyboardShownListener {
    fun onKeyboardVisible()
    fun onKeyboardHidden()
}