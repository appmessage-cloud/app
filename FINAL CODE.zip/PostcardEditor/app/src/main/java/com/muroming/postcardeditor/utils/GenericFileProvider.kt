package com.muroming.postcardeditor.utils

import androidx.core.content.FileProvider


class GenericFileProvider : FileProvider()