package com.muroming.postcardeditor.ui.fragments

enum class EditorState {
    THEMED_PRESETS,
    FRAME_PRESETS,
    FILL_PRESETS,
    USER_PICTURES,
    EDITING
}