package com.muroming.postcardeditor.data.dto

data class ApiPicture (
    val uri: String,
    val category: String
)